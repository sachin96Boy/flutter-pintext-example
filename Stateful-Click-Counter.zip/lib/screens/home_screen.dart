import 'package:flutter/material.dart';

import 'package:pin_code_fields/pin_code_fields.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final formkey = GlobalKey<FormState>();

  final otpController = TextEditingController();

  @override
  void dispose() {
    // TODO: implement dispose
    super.dispose();
    otpController.dispose();
  }

  final pinLength = 7;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('custom pincodetextfield example')),
      body: Center(
        child: Form(
          key: formkey,
          child: Column(
            children: [
              const Text('Please Enter the OTP Text Below'),
              const SizedBox(
                height: 20,
              ),
              PinCodeTextField(
                appContext: context,
                length: pinLength,
                keyboardType: TextInputType.number,
                autoFocus: true,
                pinTheme: PinTheme(
                  shape: PinCodeFieldShape.box,
                  borderRadius: BorderRadius.circular(5),
                  fieldHeight: 50,
                  fieldWidth: 50,
                  activeFillColor: Colors.white,
                ),
                controller: otpController,
                onCompleted: (value) => print(value),
                onChanged: (value) {
                  print(value);
                },
              )
            ],
          ),
        ),
      ),
    );
  }
}
